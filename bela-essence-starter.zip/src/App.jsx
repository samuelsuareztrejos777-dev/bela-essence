import React, { useEffect, useMemo, useState } from "react";

/**
 * Bela Essence – tienda básica editable (React + TailwindCSS)
 *
 * ✔️ 100% editable en interfaz (modo edición)
 * ✔️ Datos persistidos en localStorage (no se pierden al recargar)
 * ✔️ Catálogo, carrito, filtros por categoría y búsqueda
 * ✔️ Exportar/Importar JSON de contenido
 * ✔️ Botón de compra configurable (WhatsApp o Link externo)
 */

const LS_KEY = "bela_essence_site_v1";

function classNames(...xs) {
  return xs.filter(Boolean).join(" ");
}

function currency(n, locale = "es-CO", currency = "COP") {
  try {
    return new Intl.NumberFormat(locale, { style: "currency", currency }).format(n);
  } catch {
    return `$${n}`;
  }
}

// Datos demo
const demoData = {
  settings: {
    brandName: "Bela Essence",
    tagline: "Accesorios que realzan tu esencia",
    primaryCTA: "Ver colección",
    shopAction: {
      type: "whatsapp",
      whatsappNumber: "+573015274555",
      messageTemplate: "Hola quiero comprar este producto",
      linkURL: "",
    },
    socials: {
      instagram: "https://instagram.com/tu_instagram",
      whatsapp: "https://wa.me/573015274555",
      email: "hola@belaessence.com",
    },
    hero: {
      title: "Brilla todos los días",
      subtitle:
        "Descubre collares, aretes, anillos y pulseras pensados para combinar con tu estilo.",
      image:
        "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=1600&auto=format&fit=crop",
    },
  },
  categories: ["Novedades", "Aretes", "Collares", "Pulseras", "Anillos"],
  products: [
    {
      id: "p1",
      sku: "ARE-001",
      title: "Aretes perla minimal",
      description: "Baño en oro 18k. Hipoalergénicos.",
      price: 48000,
      compareAt: 56000,
      category: "Aretes",
      image:
        "https://images.unsplash.com/photo-1616279969049-c84a9741fd07?q=80&w=1400&auto=format&fit=crop",
      stock: 12,
      featured: true,
    },
    {
      id: "p2",
      sku: "COL-014",
      title: "Collar corazón zirconia",
      description: "Cadena ajustable 40–45 cm.",
      price: 69000,
      compareAt: 0,
      category: "Collares",
      image:
        "https://images.unsplash.com/photo-1601121141418-2be90a1d228a?q=80&w=1400&auto=format&fit=crop",
      stock: 8,
      featured: true,
    },
    {
      id: "p3",
      sku: "PUL-102",
      title: "Pulsera eslabones bold",
      description: "Acero inoxidable dorado.",
      price: 55000,
      compareAt: 0,
      category: "Pulseras",
      image:
        "https://images.unsplash.com/photo-1617038260897-3f9cd6b7b6d2?q=80&w=1400&auto=format&fit=crop",
      stock: 15,
      featured: false,
    },
    {
      id: "p4",
      sku: "ANI-220",
      title: "Anillo doble cruzado",
      description: "Tallas 6–8, ajustable.",
      price: 47000,
      compareAt: 0,
      category: "Anillos",
      image:
        "https://images.unsplash.com/photo-1612002321022-f2b6b65d9eca?q=80&w=1400&auto=format&fit=crop",
      stock: 6,
      featured: false,
    },
  ],
};

function useSiteData() {
  const [data, setData] = useState(() => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      return raw ? JSON.parse(raw) : demoData;
    } catch {
      return demoData;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(data));
    } catch {}
  }, [data]);

  return [data, setData];
}

function TopBar({ settings, onToggleEdit, editMode, cartCount }) {
  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur border-b">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-full bg-black text-white grid place-content-center font-semibold">BE</div>
          <div>
            <div className="text-xl font-bold leading-tight">{settings.brandName}</div>
            <div className="text-xs text-gray-500 -mt-0.5">{settings.tagline}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <a
            href={settings.socials.instagram}
            target="_blank"
            rel="noreferrer"
            className="text-sm px-3 py-1.5 rounded-full border hidden sm:inline-block"
          >
            Instagram
          </a>
          <button
            onClick={onToggleEdit}
            className={classNames(
              "text-sm px-3 py-1.5 rounded-full border",
              editMode ? "bg-black text-white" : ""
            )}
          >
            {editMode ? "Salir de edición" : "Editar sitio"}
          </button>
          <CartButton count={cartCount} />
        </div>
      </div>
    </header>
  );
}

function CartButton({ count }) {
  const [open, setOpen] = useCartDrawer();
  return (
    <button
      onClick={() => setOpen(true)}
      className="relative grid place-content-center h-9 w-9 rounded-full border"
      aria-label="Abrir carrito"
      title="Abrir carrito"
    >
      <svg viewBox="0 0 24 24" className="h-5 w-5"><path d="M7 4h-2l-1 2v2h2l2 8h10l2-8h2V6h-4l-1-2H7z" fill="currentColor"/></svg>
      {count > 0 && (
        <span className="absolute -top-1 -right-1 bg-black text-white text-[10px] px-1.5 py-0.5 rounded-full">
          {count}
        </span>
      )}
    </button>
  );
}

function Hero({ settings, scrollToShop }) {
  const { hero, primaryCTA } = settings;
  return (
    <section className="relative">
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <img src={hero.image} alt="Hero" className="h-[52vh] w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-white via-white/30 to-transparent" />
      </div>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        <div className="max-w-2xl bg-white/70 backdrop-blur rounded-3xl p-6 sm:p-8 shadow-sm">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">{hero.title}</h1>
          <p className="mt-2 text-gray-600">{hero.subtitle}</p>
          <div className="mt-5">
            <button onClick={scrollToShop} className="px-5 py-2.5 rounded-full bg-black text-white">
              {primaryCTA}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

function Filters({ categories, current, setCurrent, q, setQ }) {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto">
          {(["Todos", ...categories]).map((cat) => (
            <button
              key={cat}
              onClick={() => setCurrent(cat)}
              className={classNames(
                "px-3 py-1.5 rounded-full border whitespace-nowrap",
                current === cat ? "bg-black text-white" : ""
              )}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar producto..."
            className="px-3 py-2 rounded-xl border w-full sm:w-80"
          />
        </div>
      </div>
    </div>
  );
}

function ProductGrid({ products, onAdd, onOpen }) {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.map((p) => (
          <article key={p.id} className="bg-white rounded-2xl border overflow-hidden group">
            <button onClick={() => onOpen(p)} className="block relative">
              <img src={p.image} alt={p.title} className="h-44 w-full object-cover" />
              {p.compareAt > p.price && (
                <span className="absolute top-2 left-2 text-[11px] bg-white/90 px-2 py-0.5 rounded-full border">
                  Oferta
                </span>
              )}
            </button>
            <div className="p-3">
              <h3 className="font-medium line-clamp-1" title={p.title}>{p.title}</h3>
              <p className="text-sm text-gray-500 line-clamp-2" title={p.description}>{p.description}</p>
              <div className="mt-2 flex items-end gap-2">
                <div className="text-base font-semibold">{currency(p.price)}</div>
                {p.compareAt > p.price && (
                  <div className="text-xs line-through text-gray-400">{currency(p.compareAt)}</div>
                )}
              </div>
              <div className="mt-3">
                <button
                  onClick={() => onAdd(p)}
                  className="w-full px-3 py-2 rounded-xl bg-black text-white text-sm"
                >
                  Agregar al carrito
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

function ProductModal({ product, onClose, onAdd }) {
  if (!product) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-white rounded-2xl max-w-3xl w-full overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2">
          <img src={product.image} alt={product.title} className="h-64 md:h-full w-full object-cover" />
          <div className="p-6">
            <h3 className="text-2xl font-semibold">{product.title}</h3>
            <p className="mt-1 text-gray-600">{product.description}</p>
            <div className="mt-3 flex items-end gap-2">
              <div className="text-2xl font-bold">{currency(product.price)}</div>
              {product.compareAt > product.price && (
                <div className="text-sm line-through text-gray-400">{currency(product.compareAt)}</div>
              )}
            </div>
            <div className="mt-4 flex items-center gap-2 text-sm text-gray-500">
              <span>SKU: {product.sku}</span>
              <span>•</span>
              <span>Stock: {product.stock}</span>
            </div>
            <div className="mt-6 flex gap-2">
              <button className="px-4 py-2 rounded-xl border" onClick={onClose}>Cerrar</button>
              <button className="px-4 py-2 rounded-xl bg-black text-white" onClick={() => onAdd(product)}>Agregar al carrito</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Carrito
const CartContext = React.createContext(null);
const CartDrawerContext = React.createContext([false, () => {}]);
function useCart() { return React.useContext(CartContext); }
function useCartDrawer() { return React.useContext(CartDrawerContext); }

function CartProvider({ children }) {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);

  const add = (product) => {
    setItems((xs) => {
      const found = xs.find((i) => i.id === product.id);
      if (found) return xs.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      return [...xs, { id: product.id, title: product.title, price: product.price, sku: product.sku, image: product.image, qty: 1 }];
    });
    setOpen(true);
  };
  const remove = (id) => setItems((xs) => xs.filter((i) => i.id !== id));
  const inc = (id) => setItems((xs) => xs.map((i) => (i.id === id ? { ...i, qty: i.qty + 1 } : i)));
  const dec = (id) => setItems((xs) => xs.map((i) => (i.id === id ? { ...i, qty: Math.max(1, i.qty - 1) } : i)));
  const clear = () => setItems([]);
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);

  return (
    <CartContext.Provider value={{ items, add, remove, inc, dec, clear, total }}>
      <CartDrawerContext.Provider value={[open, setOpen]}>
        {children}
      </CartDrawerContext.Provider>
    </CartContext.Provider>
  );
}

function CartDrawer({ settings }) {
  const [open, setOpen] = useCartDrawer();
  const { items, inc, dec, remove, total, clear } = useCart();

  const checkout = () => {
    if (settings.shopAction.type === "whatsapp") {
      const num = (settings.shopAction.whatsappNumber || "").replace(/[^\d]/g, "");
      const base = settings.shopAction.messageTemplate || "Hola quiero comprar este producto";
      const lines = items.map((i) => `• ${i.title} x${i.qty} – ${currency(i.price)} (SKU ${i.sku})`).join("%0A");
      const txt = encodeURIComponent(`${base}%0A${lines}%0ATotal: ${currency(total)}`);
      const url = `https://wa.me/${num}?text=${txt}`;
      window.open(url, "_blank");
    } else if (settings.shopAction.type === "link" && settings.shopAction.linkURL) {
      window.open(settings.shopAction.linkURL, "_blank");
    } else {
      alert("Configura la acción de compra en Ajustes de tienda.");
    }
  };

  return (
    <div className={classNames("fixed inset-0 z-50", open ? "pointer-events-auto" : "pointer-events-none")}> 
      <div className={classNames("absolute inset-0 bg-black/40 transition-opacity", open ? "opacity-100" : "opacity-0")} onClick={() => setOpen(false)} />
      <aside className={classNames(
        "absolute right-0 top-0 h-full w-full sm:w-[420px] bg-white shadow-xl transition-transform", 
        open ? "translate-x-0" : "translate-x-full"
      )}>
        <div className="p-4 border-b flex items-center justify-between">
          <h3 className="text-lg font-semibold">Tu carrito</h3>
          <button className="text-sm underline" onClick={() => setOpen(false)}>Cerrar</button>
        </div>
        <div className="p-4 space-y-3 overflow-auto h-[calc(100%-192px)]">
          {items.length === 0 && <p className="text-gray-500">Aún no hay productos.</p>}
          {items.map((i) => (
            <div key={i.id} className="flex gap-3 border rounded-xl p-2">
              <img src={i.image} alt="" className="h-16 w-16 object-cover rounded-lg" />
              <div className="flex-1">
                <div className="font-medium line-clamp-1" title={i.title}>{i.title}</div>
                <div className="text-sm text-gray-500">SKU {i.sku}</div>
                <div className="mt-1 flex items-center gap-2">
                  <button className="h-6 w-6 border rounded" onClick={() => dec(i.id)}>-</button>
                  <span>{i.qty}</span>
                  <button className="h-6 w-6 border rounded" onClick={() => inc(i.id)}>+</button>
                </div>
              </div>
              <div className="text-right">
                <div className="font-semibold">{currency(i.price)}</div>
                <button className="text-xs text-red-500 mt-1" onClick={() => remove(i.id)}>Quitar</button>
              </div>
            </div>
          ))}
        </div>
        <div className="p-4 border-t">
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Subtotal</span>
            <span className="font-semibold">{currency(total)}</span>
          </div>
          <div className="mt-3 flex gap-2">
            <button className="flex-1 px-4 py-2 rounded-xl border" onClick={clear}>Vaciar</button>
            <button className="flex-1 px-4 py-2 rounded-xl bg-black text-white" onClick={checkout}>Comprar</button>
          </div>
        </div>
      </aside>
    </div>
  );
}

function EditPanel({ data, setData }) {
  const [tab, setTab] = useState("ajustes");

  const downloadJSON = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "bela-essence.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const uploadJSON = (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const obj = JSON.parse(String(reader.result));
        setData(obj);
      } catch {
        alert("Archivo inválido");
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed bottom-4 right-4 z-40">
      <div className="bg-white/90 backdrop-blur border rounded-2xl shadow-xl w-[92vw] max-w-3xl overflow-hidden">
        <div className="p-3 flex items-center justify-between border-b">
          <div className="flex items-center gap-2">
            <button className={classNames("px-3 py-1.5 rounded-full border text-sm", tab === "ajustes" && "bg-black text-white")} onClick={() => setTab("ajustes")}>Ajustes de tienda</button>
            <button className={classNames("px-3 py-1.5 rounded-full border text-sm", tab === "productos" && "bg-black text-white")} onClick={() => setTab("productos")}>Productos</button>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <button className="px-3 py-1.5 rounded-full border" onClick={downloadJSON}>Exportar JSON</button>
            <label className="px-3 py-1.5 rounded-full border cursor-pointer">
              Importar JSON
              <input type="file" accept="application/json" className="hidden" onChange={(e) => e.target.files?.[0] && uploadJSON(e.target.files[0])} />
            </label>
            <button className="px-3 py-1.5 rounded-full border" onClick={() => { if (confirm("¿Restaurar datos demo?")) setData(demoData); }}>Restaurar demo</button>
          </div>
        </div>
        <div className="max-h-[70vh] overflow-auto">
          {tab === "ajustes" ? <ShopSettings data={data} setData={setData} /> : <ProductsEditor data={data} setData={setData} />}
        </div>
      </div>
    </div>
  );
}

function Input({ label, ...props }) {
  return (
    <label className="block text-sm">
      <span className="text-gray-600">{label}</span>
      <input {...props} className={classNames("mt-1 w-full px-3 py-2 rounded-xl border", props.className)} />
    </label>
  );
}
function Textarea({ label, ...props }) {
  return (
    <label className="block text-sm">
      <span className="text-gray-600">{label}</span>
      <textarea {...props} className={classNames("mt-1 w-full px-3 py-2 rounded-xl border", props.className)} />
    </label>
  );
}

function ShopSettings({ data, setData }) {
  const s = data.settings;
  const update = (path, value) => {
    const copy = JSON.parse(JSON.stringify(data));
    const parts = path.split(".");
    let cur = copy;
    while (parts.length > 1) cur = cur[parts.shift()];
    cur[parts[0]] = value;
    setData(copy);
  };
  return (
    <div className="p-4 grid gap-3 sm:grid-cols-2">
      <Input label="Nombre de marca" value={s.brandName} onChange={(e) => update("settings.brandName", e.target.value)} />
      <Input label="Eslogan" value={s.tagline} onChange={(e) => update("settings.tagline", e.target.value)} />
      <Input label="Texto del botón principal" value={s.primaryCTA} onChange={(e) => update("settings.primaryCTA", e.target.value)} />
      <Input label="Imagen del hero (URL)" value={s.hero.image} onChange={(e) => update("settings.hero.image", e.target.value)} />
      <Input label="Título hero" value={s.hero.title} onChange={(e) => update("settings.hero.title", e.target.value)} />
      <Textarea label="Subtítulo hero" value={s.hero.subtitle} onChange={(e) => update("settings.hero.subtitle", e.target.value)} />

      <div className="sm:col-span-2 border-t pt-3 mt-2">
        <div className="font-medium mb-2">Acción de compra</div>
        <div className="grid sm:grid-cols-3 gap-3">
          <label className="flex items-center gap-2 text-sm">
            <input type="radio" name="shop_type" checked={s.shopAction.type === "whatsapp"} onChange={() => update("settings.shopAction.type", "whatsapp")} />
            WhatsApp
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="radio" name="shop_type" checked={s.shopAction.type === "link"} onChange={() => update("settings.shopAction.type", "link")} />
            Link externo (Stripe/Checkout)
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="radio" name="shop_type" checked={s.shopAction.type === "none"} onChange={() => update("settings.shopAction.type", "none")} />
            Ninguno
          </label>
        </div>
        {s.shopAction.type === "whatsapp" && (
          <div className="grid sm:grid-cols-2 gap-3 mt-2">
            <Input label="Número WhatsApp (+57...)" value={s.shopAction.whatsappNumber} onChange={(e) => update("settings.shopAction.whatsappNumber", e.target.value)} />
            <Input label="Mensaje (usa {{title}} y {{sku}} si quieres)" value={s.messageTemplate} onChange={(e) => update("settings.messageTemplate", e.target.value)} />
          </div>
        )}
        {s.shopAction.type === "link" && (
          <Input label="URL de checkout" value={s.shopAction.linkURL} onChange={(e) => update("settings.shopAction.linkURL", e.target.value)} />
        )}
      </div>

      <div className="sm:col-span-2 border-t pt-3 mt-2 grid sm:grid-cols-3 gap-3">
        <Input label="Instagram" value={s.socials.instagram} onChange={(e) => update("settings.socials.instagram", e.target.value)} />
        <Input label="WhatsApp (link)" value={s.socials.whatsapp} onChange={(e) => update("settings.socials.whatsapp", e.target.value)} />
        <Input label="Email" value={s.socials.email} onChange={(e) => update("settings.socials.email", e.target.value)} />
      </div>
    </div>
  );
}

function ProductsEditor({ data, setData }) {
  const [draft, setDraft] = useState({ id: "", title: "", price: 0, compareAt: 0, sku: "", category: "", image: "", description: "", stock: 0, featured: false });
  const [editing, setEditing] = useState(false);

  const startEdit = (p) => { setDraft(p); setEditing(true); };
  const reset = () => { setDraft({ id: "", title: "", price: 0, compareAt: 0, sku: "", category: "", image: "", description: "", stock: 0, featured: false }); setEditing(false); };

  const save = () => {
    if (!draft.title) return alert("Título requerido");
    const copy = JSON.parse(JSON.stringify(data));
    if (!draft.id) draft.id = `p${Date.now()}`;
    const i = copy.products.findIndex((x) => x.id === draft.id);
    if (i >= 0) copy.products[i] = draft; else copy.products.push(draft);
    if (draft.category && !copy.categories.includes(draft.category)) copy.categories.push(draft.category);
    setData(copy);
    reset();
  };

  const del = (id) => {
    if (!confirm("¿Eliminar producto?")) return;
    const copy = JSON.parse(JSON.stringify(data));
    copy.products = copy.products.filter((x) => x.id !== id);
    setData(copy);
  };

  return (
    <div className="p-4 grid gap-4 sm:grid-cols-2">
      <div>
        <div className="flex items-center justify-between mb-2">
          <h4 className="font-medium">Catálogo</h4>
          <button className="px-3 py-1.5 rounded-full border text-sm" onClick={reset}>{editing ? "Nuevo" : "Limpiar"}</button>
        </div>
        <div className="space-y-2 max-h-[55vh] overflow-auto">
          {data.products.map((p) => (
            <div key={p.id} className="flex items-center gap-3 border rounded-xl p-2">
              <img src={p.image} className="h-12 w-12 object-cover rounded-lg" />
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{p.title}</div>
                <div className="text-xs text-gray-500">{p.category} • {currency(p.price)}</div>
              </div>
              <button className="text-sm underline" onClick={() => startEdit(p)}>Editar</button>
              <button className="text-sm text-red-600 underline" onClick={() => del(p.id)}>Eliminar</button>
            </div>
          ))}
        </div>
      </div>
      <div>
        <h4 className="font-medium mb-2">{editing ? "Editar" : "Nuevo"} producto</h4>
        <div className="grid gap-2">
          <Input label="Título" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
          <Textarea label="Descripción" value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} />
          <div className="grid grid-cols-2 gap-2">
            <Input label="Precio" type="number" value={draft.price} onChange={(e) => setDraft({ ...draft, price: Number(e.target.value) })} />
            <Input label="Precio anterior (tachado)" type="number" value={draft.compareAt} onChange={(e) => setDraft({ ...draft, compareAt: Number(e.target.value) })} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Input label="SKU" value={draft.sku} onChange={(e) => setDraft({ ...draft, sku: e.target.value })} />
            <Input label="Stock" type="number" value={draft.stock} onChange={(e) => setDraft({ ...draft, stock: Number(e.target.value) })} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Input label="Categoría" value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value })} />
            <label className="flex items-center gap-2 text-sm mt-6">
              <input type="checkbox" checked={draft.featured} onChange={(e) => setDraft({ ...draft, featured: e.target.checked })} />
              Destacado
            </label>
          </div>
          <Input label="Imagen (URL)" value={draft.image} onChange={(e) => setDraft({ ...draft, image: e.target.value })} />
          <div className="flex gap-2 mt-1">
            {editing && <button className="px-4 py-2 rounded-xl border" onClick={reset}>Cancelar</button>}
            <button className="px-4 py-2 rounded-xl bg-black text-white" onClick={save}>{editing ? "Guardar cambios" : "Agregar"}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Footer({ settings }) {
  const s = settings.socials;
  return (
    <footer className="border-t py-8 mt-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="text-lg font-semibold">{settings.brandName}</div>
            <div className="text-sm text-gray-500">{settings.tagline}</div>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <a className="px-3 py-1.5 rounded-full border" href={s.instagram} target="_blank" rel="noreferrer">Instagram</a>
            <a className="px-3 py-1.5 rounded-full border" href={s.whatsapp} target="_blank" rel="noreferrer">WhatsApp</a>
            <a className="px-3 py-1.5 rounded-full border" href={`mailto:${s.email}`}>Email</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function AppInner() {
  const [data, setData] = useSiteData();
  const [editMode, setEditMode] = useState(false);
  const [category, setCategory] = useState("Todos");
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState(null);

  const filtered = useMemo(() => {
    let xs = [...data.products];
    if (category !== "Todos") xs = xs.filter((p) => p.category === category);
    if (q.trim()) {
      const s = q.toLowerCase();
      xs = xs.filter((p) => `${p.title} ${p.description} ${p.sku}`.toLowerCase().includes(s));
    }
    return xs;
  }, [data.products, category, q]);

  const { add, items } = useCart();
  const shopRef = React.useRef(null);
  const scrollToShop = () => shopRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 text-gray-900">
      <TopBar settings={data.settings} onToggleEdit={() => setEditMode((v) => !v)} editMode={editMode} cartCount={items.length} />
      <Hero settings={data.settings} scrollToShop={scrollToShop} />
      <div ref={shopRef} />
      <Filters categories={data.categories} current={category} setCurrent={setCategory} q={q} setQ={setQ} />
      <ProductGrid products={filtered} onAdd={add} onOpen={(p) => setSelected(p)} />
      <Footer settings={data.settings} />
      <CartDrawer settings={data.settings} />
      {selected && <ProductModal product={selected} onClose={() => setSelected(null)} onAdd={add} />}
      {editMode && <EditPanel data={data} setData={setData} />}
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <AppInner />
    </CartProvider>
  );
}
